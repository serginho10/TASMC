<?php

	class Equipaje{
		private $idEquipaje;
		private $nombre;

		public function Equipaje($idEquipaje, $nombre){
			$this->idEquipaje = $idEquipaje;
			$this->nombre = $nombre;
		}
	}

?>