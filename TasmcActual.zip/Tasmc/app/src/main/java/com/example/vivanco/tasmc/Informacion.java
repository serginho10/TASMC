package com.example.vivanco.tasmc;

/**
 * Created by VIVANCO on 12/01/2015.
 */
public class Informacion {
    int iconId;
    String titulo;
}
