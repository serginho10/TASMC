package com.example.vivanco.tasmc;

/**
 * Created by VIVANCO on 20/04/2015.
 */
public class RenglonCheck {
    private String objeto;
    private boolean checked;

    public String getObjeto() {
        return objeto;
    }

    public void setObjeto(String objeto) {
        this.objeto = objeto;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

}
